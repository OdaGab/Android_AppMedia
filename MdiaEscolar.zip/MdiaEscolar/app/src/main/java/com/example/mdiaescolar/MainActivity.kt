package com.example.mdiaescolar

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.mdiaescolar.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btCalcular.setOnClickListener{
            val nota1 = binding.editNota01.text.toString()
            val nota2 = binding.editNota02.text.toString()
            val nota3 = binding.editNota03.text.toString()
            val nota4 = binding.editNota04.text.toString()
            val faltas= binding.editFaltas.text.toString()

            if (nota1.isEmpty() || nota2.isEmpty() || nota3.isEmpty() || nota4.isEmpty() || faltas.isEmpty()){
                binding.txtResultado.setText("Preencha os campos!")
                binding.txtResultado.setTextColor(getColor(R.color.cor_04))
            }else{
                calcularMedia(nota1.toInt(),nota2.toInt(),nota3.toInt(),nota4.toInt(), faltas.toInt() )
            }
        }
    }
        fun calcularMedia(nota1: Int,nota2: Int,nota3: Int,nota4: Int,faltas: Int){
            val media = (nota1 + nota2 + nota3 + nota4) / 4

            if(media >= 6 && faltas <= 20){
               binding.txtResultado.setText("Aluno aprovado com média = $media \n Faltas = $faltas")
                binding.txtResultado.setTextColor(getColor(R.color.black))
            }else if (faltas > 20){
                binding.txtResultado.setText("Aluno reprovado por FALTAS \n $faltas")
                binding.txtResultado.setTextColor(getColor(R.color.black))
            }else if (media < 6){
                binding.txtResultado.setText("Aluno reprovado por media menor 6 \n $media")
                binding.txtResultado.setTextColor(getColor(R.color.black))
            }

    }

}